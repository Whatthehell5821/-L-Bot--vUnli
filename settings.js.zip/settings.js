const chalk = require("chalk")
const fs = require("fs")


//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'
//thumbnail variants 
global.thumb2 = "https://telegra.ph/file/54564ad98d688ebae186b.jpg"
global.thumb3 = "https://telegra.ph/file/702ea49f8c16668a72331.jpg"
global.thumb4 = "https://telegra.ph/file/29cf1afdb34182b5d8982.jpg"
global.thumb5 = "https://telegra.ph/file/3a7488934c50ae414f2e7.jpg"
global.thumb6 = "https://telegra.ph/file/a1a53c9542862e3e8b28a.jpg"
global.thumb7 = "https://telegra.ph/file/1b326f4268a32870ca37a.jpg"
global.thumb8 = "https://telegra.ph/file/b70906e0240eacddfadbc.jpg"
global.thumb9 = "https://telegra.ph/file/af3ba678fd8bd87db36ff.jpg"
global.thumb11 = "https://telegra.ph/file/5b0e0cd6a0aeea0fafe40.jpg"
global.thumb12 = "https://telegra.ph/file/42064e0a86e19db0e3fad.jpg"
global.thumb13 = "https://telegra.ph/file/bc4222f40c93dab2b107e.jpg"
global.thumb14 = "https://telegra.ph/file/9bbd2e0e6b4e6baa61406.jpg"
global.thumb15 = "https://telegra.ph/file/ea4fb8405470fd87f32b3.jpg"
global.thumb16 = "https://telegra.ph/file/a10e56439fa8be6f42c89.jpg"
global.thumb17 = "https://telegra.ph/file/b384a1263f36bf7ad5e8e.jpg"
global.thumb18 = "https://telegra.ph/file/ada395f5f8c46221be8ff.jpg"

//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "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"

//batas
global.APIKeys = {
    'https://api.shinoa.xyz/docs': '451C1A14'
}

//owmner v card
global.owner = ['6287862115557'] //ur owner number
global.ownernomer = "6287862115557" //ur owner number2
global.ownername = "𖤍 Wahyudi" //ur owner name
global.namaku = "🅆🄰🄷🅈🅄🄳🄸"
global.idgc = "120363248826862499@g.us"
global.ytname = "Unlimited karma" //ur yt chanel name
global.socialm = "Berusaha menjadi orang yang berguna" //ur github or insta name
global.location = "Indonesia, Sulawesi, Sulbar, Mamuju" //ur location


//Server crete panel egg biasa
global.domain = 'https://faapengenpensi.kangpanel.biz.id' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_LM3YDNseJIVMNXXvCMrcmc0nQi1ENSPCivCkefFjwOA' // Isi Apikey Plta Lu
global.capikey = 'ptlc_W6D0oFQWiU8Job2pkLwGlnerNGhOJgZ0QCbZANH57z2' // Isi Apikey Pltc Lu
//===========================//
//Server create panel egg pm2
global.apikey2 = 'ptla_LM3YDNseJIVMNXXvCMrcmc0nQi1ENSPCivCkefFjwOA' // Isi Apikey Plta Lu
global.capikey2 = 'ptlc_W6D0oFQWiU8Job2pkLwGlnerNGhOJgZ0QCbZANH57z2' // Isi Apikey Pltc Lu
global.domain2 = 'https://faapengenpensi.kangpanel.biz.id' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah

global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
//===========================//

//new
global.saluran = '⩽⌨︎⩾ whyu-xPloid' // Opsional 
global.idsal = "120363276932111522@newsletter" // Opsional
global.botname = "[🅛]ᴮᵒᵗ"
global.ownernumber = '6287862115557'
global.ownername = '🅆🄰🄷🅈🅄🄳🄸'
global.ownerNumber = ["6287862115557@s.whatsapp.net"]
global.ownerweb = ""
global.websitex = "https://wa.me/6287862115557"
global.wagc = "https://chat.whatsapp.com/LRqmoU6hbryGIdDAkPjJDa"
global.themeemoji = '🔥'
global.wm = "ワヒディ[whyu]-xD"
global.wmbot = "Created by 🅆🄰🄷🅈🅄🄳🄸"
global.botscript = 'private' //script link
global.packname = "╭─────────────\n⌬︱ 🅆🄰🄷🅈🅄🄳🄸\n⌬︱ /6287862115557\n⌬︱ ワヒディ [🅛]ᴮᵒᵗ\n╰─────────────"
global.author = ""
//global.packname = "By [🅛]ᴮᵒᵗ"
//global.author = "🅆🄰🄷🅈🅄🄳🄸\n\n\n\nNumber?\n\n+6287862115557"
global.creator = "6287862115557@s.whatsapp.net"
global.prefa = ['','!','.','#','&']
global.hituet = 0
global.running = "Niat dalam Hati"
//media target
global.thum = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur logo pic
global.err4r = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur error pic
global.thumb = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur thumb pic

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//false=disable and true=enable
global.autoRecording = false //auto recording
global.autoTyping = false //auto typing
global.autorecordtype = false //auto typing + recording
global.autobio = false //auto update bio
global.autoswview = true //auto view status/story
global.pengingat = true
global.autoRestart = true
//messages
global.mess = {
    success: '✓Succes kak >\\\<',
    admin: '∅ 🄰🄲🄲🄴🅂 🄳🄸🅃🄾🄻🄰🄺\nꜰᴇᴀᴛᴜʀᴇ ᴋʜᴜꜱᴜꜱ ᴀᴅᴍɪɴ ɢʀᴏᴜᴩ',
    botAdmin: 'bot harus menjadi admin terlebih dahulu',
    premime: '∅ 🄰🄲🄲🄴🅂 🄳🄸🅃🄾🄻🄰🄺\nꜰᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜꜱᴜꜱ ᴜꜱᴇʀ ᴩʀᴇᴍɪᴜᴍ',
    owner: '∅ 🄰🄲🄲🄴🅂 🄳🄸🅃🄾🄻🄰🄺\nꜰᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ',
    group: '∅ 🄰🄲🄲🄴🅂 🄳🄸🅃🄾🄻🄰🄺\nꜰᴇᴀᴛᴜʀᴇ ɪɴɪ ʜᴀɴyᴀ ʙɪꜱᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ɢʀᴏᴜᴩ',
    private: '∅ 🄰🄲🄲🄴🅂 🄳🄸🅃🄾🄻🄰🄺\nꜰᴇᴀᴛᴜʀᴇ ɪɴɪ ʜᴀɴyᴀ ʙɪꜱᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴄʜᴀᴛ ᴩʀɪᴠᴀᴛᴇ',
    bot: 'fitur khusus bot',
    wait: '🅟🅛🅔🅐🅢🅔 🅦🅐🅘🅣',
    linkm: 'masukan linknya',
    endLimit: 'limit kamu sudah habis, limit akan di reset setelah 12 jam',
    nsfw: '*"Celakalah mereka yang berlomba lomba mencari kemaksiatan"*\n\n> _Gunakan perintah .nsfw on untuk mengaktifkan fitur nsfw di group ini_',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})