const _0x41dcb8 = _0x3f2d;
(function (_0x5e1f28, _0x1ec34a) {
    const _0x4ffdf0 = _0x3f2d,
        _0x352708 = _0x5e1f28();
    while (!![]) {
        try {
            const _0x57b352 = parseInt(_0x4ffdf0(0x11b)) / 0x1 * (-parseInt(_0x4ffdf0(0xa1)) / 0x2) + parseInt(_0x4ffdf0(0x86)) / 0x3 + parseInt(_0x4ffdf0(0x7f)) / 0x4 * (-parseInt(_0x4ffdf0(0xf9)) / 0x5) + -parseInt(_0x4ffdf0(0x6f)) / 0x6 * (parseInt(_0x4ffdf0(0x85)) / 0x7) + parseInt(_0x4ffdf0(0xf3)) / 0x8 + parseInt(_0x4ffdf0(0xfb)) / 0x9 + parseInt(_0x4ffdf0(0xc6)) / 0xa;
            if (_0x57b352 === _0x1ec34a) break;
            else _0x352708['push'](_0x352708['shift']());
        } catch (_0x50e707) {
            _0x352708['push'](_0x352708['shift']());
        }
    }
}(_0x1466, 0x6b45f));
const {
    modul
} = require(_0x41dcb8(0x91)), moment = require('moment-timezone'), {
    baileys,
    boom,
    chalk,
    fs,
    figlet,
    FileType,
    path,
    pino,
    process,
    PhoneNumber
} = modul, {
    Boom
} = boom, {
    default: XeonBotIncConnect,
    useSingleFileAuthState,
    fetchLatestBaileysVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    jidDecode,
    proto
} = require('@adiwajshing/baileys'), {
    default: makeWASocket,
    BufferJSON,
    initInMemoryKeyStore,
    DisconnectReason,
    AnyMessageContent,
    makeInMemoryStore,
    useMultiFileAuthState,
    delay
} = require(_0x41dcb8(0x96)), {
    color,
    bgcolor
} = require('./lib/color'), colors = require(_0x41dcb8(0x8e)), readline = require(_0x41dcb8(0x141)), {
    uncache,
    nocache
} = require(_0x41dcb8(0x11c)), {
    start
} = require('./lib/spinner'), {
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid
} = require(_0x41dcb8(0x11f)), {
    smsg,
    isUrl,
    generateMessageTag,
    getBuffer,
    getSizeMedia,
    fetchJson,
    await,
    sleep,
    reSize
} = require(_0x41dcb8(0x103)), owner = JSON['parse'](fs[_0x41dcb8(0xdd)](_0x41dcb8(0xa6))), mongoDB = require(_0x41dcb8(0x111)), store = makeInMemoryStore({
    'logger': pino()[_0x41dcb8(0x136)]({
        'level': _0x41dcb8(0x11d),
        'stream': _0x41dcb8(0x124)
    })
}), question = _0x24bbd2 => {
    const _0x4c6e58 = _0x41dcb8,
        _0x30013e = readline[_0x4c6e58(0x8a)]({
            'input': process['stdin'],
            'output': process[_0x4c6e58(0x12b)]
        });
    return new Promise(_0x1903fb => {
        const _0x33de4a = _0x4c6e58;
        _0x30013e[_0x33de4a(0x11a)](_0x24bbd2, _0x1903fb);
    });
}, usePairingCode = !![];
require(_0x41dcb8(0x140)), nocache(_0x41dcb8(0x112), _0x1318a2 => console[_0x41dcb8(0x120)](color(_0x41dcb8(0x7c), _0x41dcb8(0x80)), color('\'' + _0x1318a2 + '\'', _0x41dcb8(0x80)), _0x41dcb8(0x12a))), require(_0x41dcb8(0x116)), nocache(_0x41dcb8(0x70), _0x3faafd => console[_0x41dcb8(0x120)](color('[ CHANGE ]', _0x41dcb8(0x80)), color('\'' + _0x3faafd + '\'', _0x41dcb8(0x80)), _0x41dcb8(0x12a)));

function title() {
    const _0x172fc9 = _0x41dcb8;
    console[_0x172fc9(0x12d)](), console[_0x172fc9(0x120)](chalk[_0x172fc9(0x10f)](_0x172fc9(0x137) + chalk[_0x172fc9(0xb8)]['yellow']('[ ' + botname + ' ]') + '\x0a\x0a')), console[_0x172fc9(0x120)](color(_0x172fc9(0xae), _0x172fc9(0xa5))), console[_0x172fc9(0x120)](color('\x0a' + themeemoji + _0x172fc9(0x74), _0x172fc9(0x75))), console['log'](color(themeemoji + _0x172fc9(0xff), _0x172fc9(0x75))), console['log'](color(themeemoji + ' WA NUMBER: ' + owner, _0x172fc9(0x75))), console[_0x172fc9(0x120)](color(themeemoji + _0x172fc9(0xc0) + wm + '\x0a', _0x172fc9(0x75)));
}
async function XeonBotIncBot() {
    const _0x5197a2 = _0x41dcb8,
        {
            state: _0xc86dbe,
            saveCreds: _0x57b6aa
        } = await useMultiFileAuthState(_0x5197a2(0xb3)),
        _0x4155b4 = XeonBotIncConnect({
            'logger': pino({
                'level': _0x5197a2(0x11d)
            }),
            'printQRInTerminal': !usePairingCode,
            'auth': _0xc86dbe,
            'browser': [_0x5197a2(0xea), '', '']
        });
    if (usePairingCode && !_0x4155b4[_0x5197a2(0x115)][_0x5197a2(0x100)][_0x5197a2(0xfc)]) {
        const _0x255c05 = await question(_0x5197a2(0x78)),
            _0xf32a3 = await _0x4155b4[_0x5197a2(0x133)](_0x255c05[_0x5197a2(0x127)]());
        console['log'](_0x5197a2(0x92) + _0xf32a3);
    }
    return console[_0x5197a2(0x120)](color(figlet[_0x5197a2(0x108)](_0x5197a2(0x132), {
        'font': _0x5197a2(0xc7),
        'horizontalLayout': _0x5197a2(0xe4),
        'vertivalLayout': 'default',
        'whitespaceBreak': ![]
    }), _0x5197a2(0xb9))), _0x4155b4['ws']['on']('CB:Blocklist', _0x3f2f6b => {
        const _0x1575ff = _0x5197a2;
        if (blocked[_0x1575ff(0x134)] > 0x2) return;
        for (let _0x41a6b3 of _0x3f2f6b[0x1]['blocklist']) {
            blocked['push'](_0x41a6b3[_0x1575ff(0xd1)](_0x1575ff(0x121), _0x1575ff(0x88)));
        }
    }), _0x4155b4['ev']['on'](_0x5197a2(0xad), async _0x42987a => {
        const _0x20f449 = _0x5197a2;
        try {
            kay = _0x42987a['messages'][0x0];
            if (!kay[_0x20f449(0x7a)]) return;
            kay[_0x20f449(0x7a)] = Object['keys'](kay[_0x20f449(0x7a)])[0x0] === _0x20f449(0xcf) ? kay[_0x20f449(0x7a)][_0x20f449(0xcf)]['message'] : kay[_0x20f449(0x7a)];
            if (kay[_0x20f449(0x8c)] && kay[_0x20f449(0x8c)][_0x20f449(0x106)] === _0x20f449(0xa4)) return;
            if (!_0x4155b4[_0x20f449(0x10a)] && !kay[_0x20f449(0x8c)][_0x20f449(0x7d)] && _0x42987a['type'] === _0x20f449(0xd7)) return;
            if (kay[_0x20f449(0x8c)]['id']['startsWith']('BAE5') && kay[_0x20f449(0x8c)]['id'][_0x20f449(0x134)] === 0x10) return;
            m = smsg(_0x4155b4, kay, store), require('./case')(_0x4155b4, m, _0x42987a, store);
        } catch (_0x3c614a) {
            console['log'](_0x3c614a);
        }
    }), _0x4155b4['ev']['on']('groups.update', async _0x30b3e5 => {
        const _0x31b1f0 = _0x5197a2;
        try {
            ppgroup = await _0x4155b4[_0x31b1f0(0x8d)](anu['id'], _0x31b1f0(0xf0));
        } catch (_0x6c051c) {
            ppgroup = 'https://i.ibb.co/RBx5SQC/avatar-group-large-v2.png?q=60';
        }
        console['log'](_0x30b3e5);
        const _0x47a4e6 = _0x30b3e5[0x0];
        if (_0x47a4e6[_0x31b1f0(0xc8)] == !![]) await sleep(0x7d0), _0x4155b4['sendMessage'](_0x47a4e6['id'], {
            'text': _0x31b1f0(0xab)
        });
        else {
            if (_0x47a4e6[_0x31b1f0(0xc8)] == ![]) await sleep(0x7d0), _0x4155b4['sendMessage'](_0x47a4e6['id'], {
                'text': _0x31b1f0(0xa8)
            });
            else {
                if (_0x47a4e6[_0x31b1f0(0x13f)] == !![]) await sleep(0x7d0), _0x4155b4['sendMessage'](_0x47a4e6['id'], {
                    'text': _0x31b1f0(0xda)
                });
                else {
                    if (_0x47a4e6[_0x31b1f0(0x13f)] == ![]) await sleep(0x7d0), _0x4155b4[_0x31b1f0(0x6e)](_0x47a4e6['id'], {
                        'text': _0x31b1f0(0xb7)
                    });
                    else !_0x47a4e6[_0x31b1f0(0xcb)] == '' ? (await sleep(0x7d0), _0x4155b4[_0x31b1f0(0x6e)](_0x47a4e6['id'], {
                        'text': _0x31b1f0(0x122) + _0x47a4e6['desc']
                    })) : (await sleep(0x7d0), _0x4155b4['sendMessage'](_0x47a4e6['id'], {
                        'text': _0x31b1f0(0x77) + _0x47a4e6['subject'] + '*'
                    }));
                }
            }
        }
    }), global[_0x5197a2(0x10d)] = global['db'], global[_0x5197a2(0xe8)] = async function _0x611b27() {
        const _0x4c0549 = _0x5197a2;
        if (global['db']['READ']) return new Promise(_0xc683da => setInterval(function () {
            const _0x2adadc = _0x3f2d;
            !global['db'][_0x2adadc(0x138)] ? (clearInterval(this), _0xc683da(global['db']['data'] == null ? global['loadDatabase']() : global['db'][_0x2adadc(0x9f)])) : null;
        }, 0x1 * 0x3e8));
        if (global['db'][_0x4c0549(0x9f)] !== null) return;
        global['db'][_0x4c0549(0x138)] = !![], await global['db'][_0x4c0549(0xa7)](), global['db'][_0x4c0549(0x138)] = ![], global['db'][_0x4c0549(0x9f)] = {
            'users': {},
            'chats': {},
            'game': {},
            'database': {},
            'settings': {},
            'setting': {},
            'others': {},
            'sticker': {},
            ...global['db'][_0x4c0549(0x9f)] || {}
        }, global['db'][_0x4c0549(0x9e)] = _['chain'](global['db']['data']);
    }, loadDatabase(), _0x4155b4['ev']['on']('group-participants.update', async _0x3ed2f6 => {
        const _0x356181 = _0x5197a2;
        console[_0x356181(0x120)](_0x3ed2f6);
        try {
            let _0x39eefa = await _0x4155b4['groupMetadata'](_0x3ed2f6['id']),
                _0x174108 = _0x3ed2f6['participants'];
            for (let _0x2016a2 of _0x174108) {
                try {
                    ppuser = await _0x4155b4['profilePictureUrl'](_0x2016a2, _0x356181(0xf0));
                } catch (_0x4e9e43) {
                    ppuser = _0x356181(0x113);
                }
                try {
                    ppgroup = await _0x4155b4['profilePictureUrl'](_0x3ed2f6['id'], _0x356181(0xf0));
                } catch (_0x3b4fd5) {
                    ppgroup = _0x356181(0x8f);
                }
                memb = _0x39eefa[_0x356181(0xaf)][_0x356181(0x134)], XeonWlcm = await getBuffer(ppuser), XeonLft = await getBuffer(ppuser);
                if (_0x3ed2f6[_0x356181(0x9c)] == _0x356181(0xf4)) {
                    const _0x269269 = await getBuffer(ppuser);
                    let _0x30291f = _0x2016a2;
                    const _0x30ebfb = moment['tz'](_0x356181(0xb0))[_0x356181(0x12c)](_0x356181(0xc9)),
                        _0x469d27 = moment['tz']('Asia/Kolkata')[_0x356181(0x12c)](_0x356181(0xe2)),
                        _0x5772ba = _0x39eefa['participants'][_0x356181(0x134)];
                    xeonbody = '≼≽━━═══[ 𝗛𝗶 👋 ]═══━━━≼≽ \n│⌬ @' + _0x30291f['split']('@')[0x0] + '\n│⌬ *Telah bergabung ke Group* \n│⌬ ' + _0x39eefa[_0x356181(0xcd)] + '\n≼≽════════❖════════≼≽', _0x4155b4['sendMessage'](_0x3ed2f6['id'], {
                        'text': xeonbody,
                        'contextInfo': {
                            'mentionedJid': [_0x2016a2],
                            'externalAdReply': {
                                'showAdAttribution': !![],
                                'containsAutoReply': !![],
                                'title': 'ワヒディ ||•' + global[_0x356181(0x9b)],
                                'body': '' + ownername,
                                'previewType': _0x356181(0xec),
                                'thumbnailUrl': '',
                                'thumbnail': XeonWlcm,
                                'sourceUrl': '' + wagc
                            }
                        }
                    });
                } else {
                    if (_0x3ed2f6[_0x356181(0x9c)] == _0x356181(0xcc)) {
                        const _0x5d12e5 = await getBuffer(ppuser),
                            _0x2cd683 = moment['tz'](_0x356181(0xb0))['format'](_0x356181(0xc9)),
                            _0x270d5f = moment['tz'](_0x356181(0xb0))[_0x356181(0x12c)]('DD/MM/YYYY');
                        let _0x45715f = _0x2016a2;
                        const _0x11c7de = _0x39eefa[_0x356181(0xaf)][_0x356181(0x134)];
                        xeonbody = '≼≽━━═[ 𝗚𝗼𝗼𝗱𝗯𝘆𝗲 👋 ]═━━≼≽\n│⌬ @' + _0x45715f[_0x356181(0x98)]('@')[0x0] + '\n│⌬ *Telah Meninggalkan group* \n│⌬ ' + _0x39eefa[_0x356181(0xcd)] + '\n≼≽════════❖════════≼≽`', _0x4155b4['sendMessage'](_0x3ed2f6['id'], {
                            'text': xeonbody,
                            'contextInfo': {
                                'mentionedJid': [_0x2016a2],
                                'externalAdReply': {
                                    'showAdAttribution': !![],
                                    'containsAutoReply': !![],
                                    'title': 'ワヒディ ||•' + global['botname'],
                                    'body': '' + ownername,
                                    'previewType': _0x356181(0xec),
                                    'thumbnailUrl': '',
                                    'thumbnail': XeonLft,
                                    'sourceUrl': '' + wagc
                                }
                            }
                        });
                    } else {
                        if (_0x3ed2f6[_0x356181(0x9c)] == _0x356181(0x8b)) {
                            const _0x340652 = await getBuffer(ppuser),
                                _0x271233 = moment['tz'](_0x356181(0xb0))['format'](_0x356181(0xc9)),
                                _0x11cb0a = moment['tz'](_0x356181(0xb0))['format'](_0x356181(0xe2));
                            let _0x28ebe4 = _0x2016a2;
                            xeonbody = _0x356181(0xe5) + _0x28ebe4[_0x356181(0x98)]('@')[0x0] + _0x356181(0xd2), _0x4155b4[_0x356181(0x6e)](_0x3ed2f6['id'], {
                                'text': xeonbody,
                                'contextInfo': {
                                    'mentionedJid': [_0x2016a2],
                                    'externalAdReply': {
                                        'showAdAttribution': !![],
                                        'containsAutoReply': !![],
                                        'title': ' ' + global[_0x356181(0x9b)],
                                        'body': '' + ownername,
                                        'previewType': _0x356181(0xec),
                                        'thumbnailUrl': '',
                                        'thumbnail': XeonWlcm,
                                        'sourceUrl': '' + wagc
                                    }
                                }
                            });
                        } else {
                            if (_0x3ed2f6[_0x356181(0x9c)] == 'demote') {
                                const _0xba29d2 = await getBuffer(ppuser),
                                    _0xaf4b4e = moment['tz'](_0x356181(0xb0))[_0x356181(0x12c)](_0x356181(0xc9)),
                                    _0x276f07 = moment['tz'](_0x356181(0xb0))[_0x356181(0x12c)](_0x356181(0xe2));
                                let _0x392b20 = _0x2016a2;
                                xeonbody = _0x356181(0xa9) + _0x392b20[_0x356181(0x98)]('@')[0x0] + _0x356181(0xfd), _0x4155b4[_0x356181(0x6e)](_0x3ed2f6['id'], {
                                    'text': xeonbody,
                                    'contextInfo': {
                                        'mentionedJid': [_0x2016a2],
                                        'externalAdReply': {
                                            'showAdAttribution': !![],
                                            'containsAutoReply': !![],
                                            'title': ' ' + global[_0x356181(0x9b)],
                                            'body': '' + ownername,
                                            'previewType': _0x356181(0xec),
                                            'thumbnailUrl': '',
                                            'thumbnail': XeonLft,
                                            'sourceUrl': '' + wagc
                                        }
                                    }
                                });
                            }
                        }
                    }
                }
            }
        } catch (_0x3b3910) {
            console['log'](_0x3b3910);
        }
    }), _0x4155b4[_0x5197a2(0x93)] = async (_0x4572b0, _0x563f82, _0x1c5f23, _0x43aa34 = {}) => _0x4155b4[_0x5197a2(0x6e)](_0x4572b0, {
        'text': _0x563f82,
        'contextInfo': {
            'mentionedJid': [..._0x563f82[_0x5197a2(0xeb)](/@(\d{0,16})/g)][_0x5197a2(0xce)](_0x5cac7b => _0x5cac7b[0x1] + _0x5197a2(0xa2))
        },
        ..._0x43aa34
    }, {
        'quoted': _0x1c5f23
    }), _0x4155b4['decodeJid'] = _0x10ec64 => {
        const _0x4b9423 = _0x5197a2;
        if (!_0x10ec64) return _0x10ec64;
        if (/:\d+@/gi [_0x4b9423(0xa0)](_0x10ec64)) {
            let _0x54bf04 = jidDecode(_0x10ec64) || {};
            return _0x54bf04[_0x4b9423(0xc2)] && _0x54bf04[_0x4b9423(0x128)] && _0x54bf04[_0x4b9423(0xc2)] + '@' + _0x54bf04[_0x4b9423(0x128)] || _0x10ec64;
        } else return _0x10ec64;
    }, _0x4155b4['ev']['on'](_0x5197a2(0xba), _0x2e3148 => {
        const _0x35b6d5 = _0x5197a2;
        for (let _0xeebd39 of _0x2e3148) {
            let _0x426382 = _0x4155b4['decodeJid'](_0xeebd39['id']);
            if (store && store[_0x35b6d5(0xdb)]) store[_0x35b6d5(0xdb)][_0x426382] = {
                'id': _0x426382,
                'name': _0xeebd39['notify']
            };
        }
    }), _0x4155b4[_0x5197a2(0x102)] = (_0x3bb396, _0x2082fb = ![]) => {
        const _0x4d0f45 = _0x5197a2;
        id = _0x4155b4[_0x4d0f45(0xc1)](_0x3bb396), _0x2082fb = _0x4155b4[_0x4d0f45(0xac)] || _0x2082fb;
        let _0xe7da2f;
        if (id['endsWith']('@g.us')) return new Promise(async _0x1faa34 => {
            const _0x151b0e = _0x4d0f45;
            _0xe7da2f = store['contacts'][id] || {};
            if (!(_0xe7da2f[_0x151b0e(0x109)] || _0xe7da2f[_0x151b0e(0xcd)])) _0xe7da2f = _0x4155b4[_0x151b0e(0xf7)](id) || {};
            _0x1faa34(_0xe7da2f[_0x151b0e(0x109)] || _0xe7da2f[_0x151b0e(0xcd)] || PhoneNumber('+' + id[_0x151b0e(0xd1)](_0x151b0e(0xa2), ''))['getNumber'](_0x151b0e(0xb1)));
        });
        else _0xe7da2f = id === _0x4d0f45(0xaa) ? {
            'id': id,
            'name': _0x4d0f45(0xc3)
        } : id === _0x4155b4[_0x4d0f45(0xc1)](_0x4155b4['user']['id']) ? _0x4155b4['user'] : store[_0x4d0f45(0xdb)][id] || {};
        return (_0x2082fb ? '' : _0xe7da2f[_0x4d0f45(0x109)]) || _0xe7da2f[_0x4d0f45(0xcd)] || _0xe7da2f[_0x4d0f45(0xe3)] || PhoneNumber('+' + _0x3bb396['replace'](_0x4d0f45(0xa2), ''))[_0x4d0f45(0xed)]('international');
    }, _0x4155b4[_0x5197a2(0x13c)] = (_0x17646c = '') => {
        const _0x496a11 = _0x5197a2;
        return [..._0x17646c[_0x496a11(0xeb)](/@([0-9]{5,16}|0)/g)][_0x496a11(0xce)](_0x37e8fe => _0x37e8fe[0x1] + _0x496a11(0xa2));
    }, _0x4155b4[_0x5197a2(0x123)] = async (_0x155c8b, _0xc345d8, _0x58d192 = '', _0x5e2774 = {}) => {
        const _0x4da595 = _0x5197a2;
        let _0xf816b4 = [];
        for (let _0x1210a0 of _0xc345d8) {
            _0xf816b4[_0x4da595(0xe1)]({
                'displayName': await _0x4155b4[_0x4da595(0x102)](_0x1210a0),
                'vcard': 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:' + await _0x4155b4[_0x4da595(0x102)](_0x1210a0) + '\x0aFN:' + await _0x4155b4[_0x4da595(0x102)](_0x1210a0) + _0x4da595(0x131) + _0x1210a0 + ':' + _0x1210a0 + '\x0aitem1.X-ABLabel:Click here to chat\x0aitem2.EMAIL;type=INTERNET:' + ytname + _0x4da595(0x125) + socialm + _0x4da595(0x73) + location + _0x4da595(0x79)
            });
        }
        _0x4155b4[_0x4da595(0x6e)](_0x155c8b, {
            'contacts': {
                'displayName': _0xf816b4[_0x4da595(0x134)] + _0x4da595(0x82),
                'contacts': _0xf816b4
            },
            ..._0x5e2774
        }, {
            'quoted': _0x58d192
        });
    }, _0x4155b4[_0x5197a2(0xf6)] = _0x3ee7db => {
        const _0x2a891d = _0x5197a2;
        return _0x4155b4[_0x2a891d(0xb2)]({
            'tag': 'iq',
            'attrs': {
                'to': _0x2a891d(0xa2),
                'type': _0x2a891d(0xf8),
                'xmlns': _0x2a891d(0x117)
            },
            'content': [{
                'tag': _0x2a891d(0x117),
                'attrs': {},
                'content': Buffer['from'](_0x3ee7db, _0x2a891d(0xb5))
            }]
        }), _0x3ee7db;
    }, _0x4155b4[_0x5197a2(0x10a)] = !![], _0x4155b4[_0x5197a2(0xd9)] = async (_0x5c90aa, _0x5d68d7, _0x3e4094 = '', _0x4fcc90 = '', _0x243f09) => {
        const _0x65e671 = _0x5197a2;
        let _0x2f8707 = Buffer[_0x65e671(0x104)](_0x5d68d7) ? _0x5d68d7 : /^data:.*?\/.*?;base64,/i [_0x65e671(0xa0)](_0x5d68d7) ? Buffer[_0x65e671(0x9d)](_0x5d68d7[_0x65e671(0x98)]
            `,` [0x1], _0x65e671(0x12f)) : /^https?:\/\// [_0x65e671(0xa0)](_0x5d68d7) ? await await getBuffer(_0x5d68d7) : fs[_0x65e671(0xc4)](_0x5d68d7) ? fs[_0x65e671(0xdd)](_0x5d68d7) : Buffer[_0x65e671(0xbc)](0x0);
        return await _0x4155b4[_0x65e671(0x6e)](_0x5c90aa, {
            'image': _0x2f8707,
            'caption': _0x3e4094,
            ..._0x243f09
        }, {
            'quoted': _0x4fcc90
        });
    }, _0x4155b4['sendImageAsSticker'] = async (_0x277e40, _0x1f1661, _0x2bd931, _0x46a974 = {}) => {
        const _0x1ff75e = _0x5197a2;
        let _0x12eeb7 = Buffer[_0x1ff75e(0x104)](_0x1f1661) ? _0x1f1661 : /^data:.*?\/.*?;base64,/i [_0x1ff75e(0xa0)](_0x1f1661) ? Buffer[_0x1ff75e(0x9d)](_0x1f1661['split']
                `,` [0x1], _0x1ff75e(0x12f)) : /^https?:\/\// [_0x1ff75e(0xa0)](_0x1f1661) ? await await getBuffer(_0x1f1661) : fs[_0x1ff75e(0xc4)](_0x1f1661) ? fs[_0x1ff75e(0xdd)](_0x1f1661) : Buffer[_0x1ff75e(0xbc)](0x0),
            _0x17551c;
        _0x46a974 && (_0x46a974[_0x1ff75e(0x10e)] || _0x46a974[_0x1ff75e(0xd3)]) ? _0x17551c = await writeExifImg(_0x12eeb7, _0x46a974) : _0x17551c = await imageToWebp(_0x12eeb7), await _0x4155b4[_0x1ff75e(0x6e)](_0x277e40, {
            'sticker': {
                'url': _0x17551c
            },
            ..._0x46a974
        }, {
            'quoted': _0x2bd931
        })[_0x1ff75e(0xca)](_0x1ac810 => {
            const _0x2ce775 = _0x1ff75e;
            return fs[_0x2ce775(0x83)](_0x17551c), _0x1ac810;
        });
    }, _0x4155b4[_0x5197a2(0xd8)] = async (_0x250c9b, _0x2bcd43, _0x6b703c, _0x38f050 = {}) => {
        const _0x746172 = _0x5197a2;
        let _0x4ffc76 = Buffer['isBuffer'](_0x2bcd43) ? _0x2bcd43 : /^data:.*?\/.*?;base64,/i [_0x746172(0xa0)](_0x2bcd43) ? Buffer[_0x746172(0x9d)](_0x2bcd43[_0x746172(0x98)]
                `,` [0x1], 'base64') : /^https?:\/\// ['test'](_0x2bcd43) ? await await getBuffer(_0x2bcd43) : fs[_0x746172(0xc4)](_0x2bcd43) ? fs[_0x746172(0xdd)](_0x2bcd43) : Buffer[_0x746172(0xbc)](0x0),
            _0x552fa1;
        return _0x38f050 && (_0x38f050[_0x746172(0x10e)] || _0x38f050[_0x746172(0xd3)]) ? _0x552fa1 = await writeExifVid(_0x4ffc76, _0x38f050) : _0x552fa1 = await videoToWebp(_0x4ffc76), await _0x4155b4[_0x746172(0x6e)](_0x250c9b, {
            'sticker': {
                'url': _0x552fa1
            },
            ..._0x38f050
        }, {
            'quoted': _0x6b703c
        }), _0x552fa1;
    }, _0x4155b4['copyNForward'] = async (_0x34a5b6, _0x596dcd, _0x1ccbe0 = ![], _0x560182 = {}) => {
        const _0x3dc2c7 = _0x5197a2;
        let _0x35df46;
        _0x560182[_0x3dc2c7(0xd5)] && (_0x596dcd['message'] = _0x596dcd['message'] && _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0xcf)] && _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0xcf)][_0x3dc2c7(0x7a)] ? _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0xcf)][_0x3dc2c7(0x7a)] : _0x596dcd['message'] || undefined, _0x35df46 = Object[_0x3dc2c7(0xde)](_0x596dcd[_0x3dc2c7(0x7a)]['viewOnceMessage'][_0x3dc2c7(0x7a)])[0x0], delete(_0x596dcd[_0x3dc2c7(0x7a)] && _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0x126)] ? _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0x126)] : _0x596dcd['message'] || undefined), delete _0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0xe6)][_0x3dc2c7(0x7a)][_0x35df46]['viewOnce'], _0x596dcd[_0x3dc2c7(0x7a)] = {
            ..._0x596dcd[_0x3dc2c7(0x7a)][_0x3dc2c7(0xe6)][_0x3dc2c7(0x7a)]
        });
        let _0x385c1e = Object[_0x3dc2c7(0xde)](_0x596dcd[_0x3dc2c7(0x7a)])[0x0],
            _0x380eb6 = await generateForwardMessageContent(_0x596dcd, _0x1ccbe0),
            _0x300127 = Object[_0x3dc2c7(0xde)](_0x380eb6)[0x0],
            _0x32207a = {};
        if (_0x385c1e != _0x3dc2c7(0xbd)) _0x32207a = _0x596dcd['message'][_0x385c1e][_0x3dc2c7(0x95)];
        _0x380eb6[_0x300127][_0x3dc2c7(0x95)] = {
            ..._0x32207a,
            ..._0x380eb6[_0x300127]['contextInfo']
        };
        const _0x99516c = await generateWAMessageFromContent(_0x34a5b6, _0x380eb6, _0x560182 ? {
            ..._0x380eb6[_0x300127],
            ..._0x560182,
            ..._0x560182[_0x3dc2c7(0x95)] ? {
                'contextInfo': {
                    ..._0x380eb6[_0x300127][_0x3dc2c7(0x95)],
                    ..._0x560182[_0x3dc2c7(0x95)]
                }
            } : {}
        } : {});
        return await _0x4155b4['relayMessage'](_0x34a5b6, _0x99516c[_0x3dc2c7(0x7a)], {
            'messageId': _0x99516c[_0x3dc2c7(0x8c)]['id']
        }), _0x99516c;
    }, _0x4155b4['downloadAndSaveMediaMessage'] = async (_0xb0c809, _0x15f62f, _0x2d516a = !![]) => {
        const _0xef1909 = _0x5197a2;
        let _0x5cd530 = _0xb0c809['msg'] ? _0xb0c809[_0xef1909(0x101)] : _0xb0c809,
            _0x2a53e = (_0xb0c809['msg'] || _0xb0c809)[_0xef1909(0xbb)] || '',
            _0x457dbb = _0xb0c809['mtype'] ? _0xb0c809[_0xef1909(0x135)][_0xef1909(0xd1)](/Message/gi, '') : _0x2a53e[_0xef1909(0x98)]('/')[0x0];
        const _0xd8957 = await downloadContentFromMessage(_0x5cd530, _0x457dbb);
        let _0x26f24e = Buffer[_0xef1909(0x9d)]([]);
        for await (const _0x4496c0 of _0xd8957) {
            _0x26f24e = Buffer[_0xef1909(0xf2)]([_0x26f24e, _0x4496c0]);
        }
        let _0xbfb27b = await FileType['fromBuffer'](_0x26f24e);
        return trueFileName = _0x2d516a ? _0x15f62f + '.' + _0xbfb27b['ext'] : _0x15f62f, await fs['writeFileSync'](trueFileName, _0x26f24e), trueFileName;
    }, _0x4155b4['downloadMediaMessage'] = async _0x45410c => {
        const _0x115791 = _0x5197a2;
        let _0x24a14f = (_0x45410c[_0x115791(0x101)] || _0x45410c)[_0x115791(0xbb)] || '',
            _0x1d9ae8 = _0x45410c[_0x115791(0x135)] ? _0x45410c[_0x115791(0x135)]['replace'](/Message/gi, '') : _0x24a14f[_0x115791(0x98)]('/')[0x0];
        const _0x181744 = await downloadContentFromMessage(_0x45410c, _0x1d9ae8);
        let _0x40bd5a = Buffer[_0x115791(0x9d)]([]);
        for await (const _0x38060b of _0x181744) {
            _0x40bd5a = Buffer[_0x115791(0xf2)]([_0x40bd5a, _0x38060b]);
        }
        return _0x40bd5a;
    }, _0x4155b4[_0x5197a2(0x139)] = async (_0x197f26, _0x2d79db) => {
        const _0x525050 = _0x5197a2;
        let _0x498d48, _0x529a71 = Buffer[_0x525050(0x104)](_0x197f26) ? _0x197f26 : /^data:.*?\/.*?;base64,/i [_0x525050(0xa0)](_0x197f26) ? Buffer[_0x525050(0x9d)](_0x197f26['split']
                `,` [0x1], _0x525050(0x12f)) : /^https?:\/\// [_0x525050(0xa0)](_0x197f26) ? await (_0x498d48 = await getBuffer(_0x197f26)) : fs[_0x525050(0xc4)](_0x197f26) ? (filename = _0x197f26, fs[_0x525050(0xdd)](_0x197f26)) : typeof _0x197f26 === 'string' ? _0x197f26 : Buffer[_0x525050(0xbc)](0x0),
            _0x207ef6 = await FileType[_0x525050(0x119)](_0x529a71) || {
                'mime': _0x525050(0x105),
                'ext': _0x525050(0x12e)
            };
        filename = path[_0x525050(0x81)](__filename, _0x525050(0xef) + new Date() * 0x1 + '.' + _0x207ef6[_0x525050(0xb4)]);
        if (_0x529a71 && _0x2d79db) fs[_0x525050(0xc5)][_0x525050(0xdf)](filename, _0x529a71);
        return {
            'res': _0x498d48,
            'filename': filename,
            'size': await getSizeMedia(_0x529a71),
            ..._0x207ef6,
            'data': _0x529a71
        };
    }, _0x4155b4[_0x5197a2(0xbf)] = async (_0x423524, _0x3cad1d, _0x5dd893 = '', _0x582446 = '', _0x9f4c4c = '', _0x1d928b = {}) => {
        const _0x5e7b43 = _0x5197a2;
        let _0x19c612 = await _0x4155b4['getFile'](_0x3cad1d, !![]),
            {
                mime: _0x5936f0,
                ext: _0x975212,
                res: _0x54c3ef,
                data: _0x46ef94,
                filename: _0x5ad060
            } = _0x19c612;
        if (_0x54c3ef && _0x54c3ef[_0x5e7b43(0x117)] !== 0xc8 || file['length'] <= 0x10000) try {
            throw {
                'json': JSON['parse'](file[_0x5e7b43(0xe0)]())
            };
        } catch (_0x115615) {
            if (_0x115615[_0x5e7b43(0xe7)]) throw _0x115615[_0x5e7b43(0xe7)];
        }
        let _0x24f763 = '',
            _0x39751a = _0x5936f0,
            _0x2d4eee = _0x5ad060;
        if (_0x1d928b[_0x5e7b43(0x13e)]) _0x24f763 = 'document';
        if (_0x1d928b[_0x5e7b43(0x13b)] || /webp/ [_0x5e7b43(0xa0)](_0x5936f0)) {
            let {
                writeExif: _0x3ed795
            } = require('./lib/exif'), _0x1db96f = {
                'mimetype': _0x5936f0,
                'data': _0x46ef94
            };
            _0x2d4eee = await _0x3ed795(_0x1db96f, {
                'packname': _0x1d928b[_0x5e7b43(0x10e)] ? _0x1d928b[_0x5e7b43(0x10e)] : global[_0x5e7b43(0x10e)],
                'author': _0x1d928b[_0x5e7b43(0xd3)] ? _0x1d928b[_0x5e7b43(0xd3)] : global['author'],
                'categories': _0x1d928b[_0x5e7b43(0x9a)] ? _0x1d928b[_0x5e7b43(0x9a)] : []
            }), await fs['promises']['unlink'](_0x5ad060), _0x24f763 = _0x5e7b43(0x11e), _0x39751a = _0x5e7b43(0x87);
        } else {
            if (/image/ ['test'](_0x5936f0)) _0x24f763 = _0x5e7b43(0xf0);
            else {
                if (/video/ [_0x5e7b43(0xa0)](_0x5936f0)) _0x24f763 = 'video';
                else {
                    if (/audio/ [_0x5e7b43(0xa0)](_0x5936f0)) _0x24f763 = _0x5e7b43(0x7b);
                    else _0x24f763 = _0x5e7b43(0x89);
                }
            }
        }
        return await _0x4155b4[_0x5e7b43(0x6e)](_0x423524, {
            [_0x24f763]: {
                'url': _0x2d4eee
            },
            'caption': _0x582446,
            'mimetype': _0x39751a,
            'fileName': _0x5dd893,
            ..._0x1d928b
        }, {
            'quoted': _0x9f4c4c,
            ..._0x1d928b
        }), fs[_0x5e7b43(0xc5)][_0x5e7b43(0x10b)](_0x2d4eee);
    }, _0x4155b4[_0x5197a2(0xdc)] = (_0x1400b6, _0x2d7d90, _0x2aabdd = '', _0x2392a7) => _0x4155b4[_0x5197a2(0x6e)](_0x1400b6, {
        'text': _0x2d7d90,
        ..._0x2392a7
    }, {
        'quoted': _0x2aabdd
    }), _0x4155b4[_0x5197a2(0x118)] = _0x3486f0 => smsg(_0x4155b4, _0x3486f0, store), _0x4155b4['ev']['on'](_0x5197a2(0xa3), async _0x4b35e0 => {
        const _0x20ca9a = _0x5197a2,
            {
                connection: _0x2cb662,
                lastDisconnect: _0x5a5f89
            } = _0x4b35e0;
        if (_0x2cb662 === _0x20ca9a(0xbe)) {
            let _0xf76263 = new Boom(_0x5a5f89?. [_0x20ca9a(0xb6)])?. [_0x20ca9a(0x13d)][_0x20ca9a(0x76)];
            if (_0xf76263 === DisconnectReason[_0x20ca9a(0x110)]) console[_0x20ca9a(0x120)](_0x20ca9a(0x99)), _0x4155b4[_0x20ca9a(0x7e)]();
            else {
                if (_0xf76263 === DisconnectReason[_0x20ca9a(0xe9)]) console[_0x20ca9a(0x120)](_0x20ca9a(0x129)), XeonBotIncBot();
                else {
                    if (_0xf76263 === DisconnectReason[_0x20ca9a(0x72)]) console[_0x20ca9a(0x120)]('Connection Lost from Server, reconnecting...'), XeonBotIncBot();
                    else {
                        if (_0xf76263 === DisconnectReason['connectionReplaced']) console[_0x20ca9a(0x120)]('Connection Replaced, Another New Session Opened, Please Close Current Session First'), _0x4155b4[_0x20ca9a(0x7e)]();
                        else {
                            if (_0xf76263 === DisconnectReason['loggedOut']) console[_0x20ca9a(0x120)](_0x20ca9a(0x97)), _0x4155b4['logout']();
                            else {
                                if (_0xf76263 === DisconnectReason[_0x20ca9a(0x10c)]) console[_0x20ca9a(0x120)]('Restart Required, Restarting...'), XeonBotIncBot();
                                else {
                                    if (_0xf76263 === DisconnectReason[_0x20ca9a(0xf5)]) console[_0x20ca9a(0x120)](_0x20ca9a(0xfe)), XeonBotIncBot();
                                    else _0x4155b4[_0x20ca9a(0x107)](_0x20ca9a(0xd4) + _0xf76263 + '|' + _0x2cb662);
                                }
                            }
                        }
                    }
                }
            }
        } else _0x2cb662 === _0x20ca9a(0x90) && _0x4155b4[_0x20ca9a(0x6e)](owner + _0x20ca9a(0xa2), {
            'text': _0x20ca9a(0x130)
        });
        console[_0x20ca9a(0x120)]('Connected...', _0x4b35e0);
    }), _0x4155b4['ev']['on'](_0x5197a2(0xee), await _0x57b6aa), start('2', colors[_0x5197a2(0xb8)]['white']('\x0aMenunggu pesan yang Masuk....')), _0x4155b4[_0x5197a2(0x94)] = (_0x366276, _0xf25c1f = [], _0x14c847, _0xae8579, _0x21b181 = '', _0xf9b3c6 = {}) => {
        const _0x369ea2 = _0x5197a2;
        let _0x438a13 = {
            'text': _0x14c847,
            'footer': _0xae8579,
            'buttons': _0xf25c1f,
            'headerType': 0x2,
            ..._0xf9b3c6
        };
        _0x4155b4[_0x369ea2(0x6e)](_0x366276, _0x438a13, {
            'quoted': _0x21b181,
            ..._0xf9b3c6
        });
    }, _0x4155b4[_0x5197a2(0x84)] = async (_0x1ccbfc, _0x5d5516 = '', _0x2a780f = '', _0x35d855, _0x2dc508 = {}) => {
        const _0x2f0031 = _0x5197a2;
        let _0x30e07c = await prepareWAMessageMedia({
            'image': _0x35d855
        }, {
            'upload': _0x4155b4[_0x2f0031(0x114)]
        });
        const _0x57a2c1 = generateWAMessageFromContent(_0x1ccbfc, {
            'productMessage': {
                'product': {
                    'productImage': _0x30e07c['imageMessage'],
                    'productId': '9999',
                    'title': _0x5d5516,
                    'description': _0x2a780f,
                    'currencyCode': 'IDR',
                    'priceAmount1000': '100000',
                    'url': '' + websitex,
                    'productImageCount': 0x1,
                    'salePriceAmount1000': '0'
                },
                'businessOwnerJid': ownernumber + _0x2f0031(0xa2)
            }
        }, _0x2dc508);
        return _0x4155b4[_0x2f0031(0xd0)](_0x1ccbfc, _0x57a2c1[_0x2f0031(0x7a)], {
            'messageId': _0x57a2c1[_0x2f0031(0x8c)]['id']
        });
    }, _0x4155b4[_0x5197a2(0xfa)] = async (_0x2ee5f0, _0x231e4e = '', _0x27744b = '', _0x2677c6, _0x493cde = [], _0x4d2fe3 = {}) => {
        const _0x251d09 = _0x5197a2;
        var _0x253114 = generateWAMessageFromContent(_0x2ee5f0, proto[_0x251d09(0x71)][_0x251d09(0x13a)]({
            'templateMessage': {
                'hydratedTemplate': {
                    'hydratedContentText': _0x231e4e,
                    'locationMessage': {
                        'jpegThumbnail': _0x2677c6
                    },
                    'hydratedFooterText': _0x27744b,
                    'hydratedButtons': _0x493cde
                }
            }
        }), _0x4d2fe3);
        _0x4155b4[_0x251d09(0xd0)](_0x2ee5f0, _0x253114[_0x251d09(0x7a)], {
            'messageId': _0x253114[_0x251d09(0x8c)]['id']
        });
    }, _0x4155b4[_0x5197a2(0xd6)] = async (_0x194fd0, _0x3e1412, _0x5ae8fc, _0x23d30d, _0x57ef33) => {
        const _0x339ce4 = _0x5197a2;
        let _0x1fcedc = Buffer[_0x339ce4(0x104)](_0x3e1412) ? _0x3e1412 : /^data:.*?\/.*?;base64,/i [_0x339ce4(0xa0)](_0x3e1412) ? Buffer[_0x339ce4(0x9d)](_0x3e1412[_0x339ce4(0x98)]
                `,` [0x1], 'base64') : /^https?:\/\// [_0x339ce4(0xa0)](_0x3e1412) ? await await getBuffer(_0x3e1412) : fs['existsSync'](_0x3e1412) ? fs[_0x339ce4(0xdd)](_0x3e1412) : Buffer[_0x339ce4(0xbc)](0x0),
            _0x3d9c61 = {
                'image': _0x1fcedc,
                'jpegThumbnail': _0x1fcedc,
                'caption': _0x5ae8fc,
                'fileLength': '1',
                'footer': _0x23d30d,
                'buttons': _0x57ef33,
                'headerType': 0x4
            };
        _0x4155b4[_0x339ce4(0x6e)](_0x194fd0, _0x3d9c61, {
            'quoted': m
        });
    }, _0x4155b4;
}

function _0x3f2d(_0x377493, _0x515fee) {
    const _0x146620 = _0x1466();
    return _0x3f2d = function (_0x3f2d1d, _0x16da7b) {
        _0x3f2d1d = _0x3f2d1d - 0x6e;
        let _0x4af015 = _0x146620[_0x3f2d1d];
        return _0x4af015;
    }, _0x3f2d(_0x377493, _0x515fee);
}
XeonBotIncBot(), process['on'](_0x41dcb8(0xf1), function (_0x516de6) {
    const _0x40ed23 = _0x41dcb8;
    console[_0x40ed23(0x120)]('Caught exception: ', _0x516de6);
});

function _0x1466() {
    const _0xc15d17 = ['action', 'from', 'chain', 'data', 'test', '381878PPHtLl', '@s.whatsapp.net', 'connection.update', 'status@broadcast', 'cyan', './database/owner.json', 'read', '「 *Pemberitahuan* 」\x0a\x0aGrup Di Buka Dan Semua Peserta Dapat Mengirimkan Pesan !', 'Upss Si @', '0@s.whatsapp.net', '「 *Pemberitahuan* 」\x0a\x0aGrup Di Tutup Dan Hanya Admin Yang Dapat Mengirim Pesan !', 'withoutContact', 'messages.upsert', '< ================================================== >', 'participants', 'Asia/Kolkata', 'international', 'query', 'session', 'ext', 'utf-8', 'error', '「 Group Settings Change 」\x0a\x0aGroup info has been opened, Now participants can edit group info !', 'bold', 'aqua', 'contacts.update', 'mimetype', 'alloc', 'conversation', 'close', 'sendMedia', ' CREDIT: ', 'decodeJid', 'user', 'WhatsApp', 'existsSync', 'promises', '1485370qkBANd', 'Standard', 'announce', 'HH:mm:ss', 'then', 'desc', 'remove', 'subject', 'map', 'ephemeralMessage', 'relayMessage', 'replace', ', Naik pangkat menjadi Admin!!', 'author', 'Unknown DisconnectReason: ', 'readViewOnce', 'sendButImg', 'notify', 'sendVideoAsSticker', 'sendImage', '「 Group Settings Change 」\x0a\x0aGroup info has been restricted, Now only admin can edit group info !', 'contacts', 'sendText', 'readFileSync', 'keys', 'writeFile', 'toString', 'push', 'DD/MM/YYYY', 'verifiedName', 'default', ' Ciee Si @', 'viewOnceMessage', 'json', 'loadDatabase', 'connectionClosed', 'Chrome (Linux)', 'matchAll', 'PHOTO', 'getNumber', 'creds.update', './lib', 'image', 'uncaughtException', 'concat', '6742008ivSyhO', 'add', 'timedOut', 'setStatus', 'groupMetadata', 'set', '204655gPsPKY', 'send5ButLoc', '1297836tPMRdg', 'registered', ', Turun pangkat menjadi Member', 'Connection TimedOut, Reconnecting...', ' GITHUB: 4ksanzz ', 'creds', 'msg', 'getName', './lib/myfunc', 'isBuffer', 'application/octet-stream', 'remoteJid', 'end', 'textSync', 'name', 'public', 'unlink', 'restartRequired', 'DATABASE', 'packname', 'yellow', 'badSession', './lib/mongoDB', '../case.js', 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60', 'waUploadToServer', 'authState', './index.js', 'status', 'serializeM', 'fromBuffer', 'question', '4XBfBGo', './lib/loader', 'silent', 'sticker', './lib/exif', 'log', 'c.us', '「 Group Settings Change 」\x0a\x0a*Group description has been changed to*\x0a\x0a', 'sendContact', 'store', '\x0aitem2.X-ABLabel:YouTube\x0aitem3.URL:', 'ignore', 'trim', 'server', 'Connection closed, reconnecting....', 'Updated', 'stdout', 'format', 'clear', '.bin', 'base64', 'Bot Sudah terhubung\x0aKetik .ping untuk melakukan test\x0a\x0a\x0aTerimaKasih kak Wahyudi >//<', '\x0aitem1.TEL;waid=', 'WhyuxD', 'requestPairingCode', 'length', 'mtype', 'child', '\x0a\x0a               ', 'READ', 'getFile', 'fromObject', 'asSticker', 'parseMention', 'output', 'asDocument', 'restrict', './case.js', 'readline', 'sendMessage', '16752OEBZgi', '../index.js', 'Message', 'connectionLost', '\x0aitem3.X-ABLabel:GitHub\x0aitem4.ADR:;;', ' YT CHANNEL: FallXD425', 'magenta', 'statusCode', '「 Group Settings Change 」\x0a\x0a*Group name has been changed to*\x0a\x0a*', 'Masukan Nomer Yang Aktif Awali Dengan 62:\x0a', ';;;;\x0aitem4.X-ABLabel:Region\x0aEND:VCARD', 'message', 'audio', '[ CHANGE ]', 'fromMe', 'logout', '36rmTFvl', 'green', 'join', ' Contact', 'unlinkSync', 'sendKatalog', '623cbdhBU', '2053566IqrixF', 'image/webp', 's.whatsapp.net', 'document', 'createInterface', 'promote', 'key', 'profilePictureUrl', 'colors', 'https://i.ibb.co/RBx5SQC/avatar-group-large-v2.png?q=60', 'open', './module', 'Pairing code: ', 'sendTextWithMentions', 'sendButtonText', 'contextInfo', '@adiwajshing/baileys', 'Device Logged Out, Please Scan Again And Run.', 'split', 'Bad Session File, Please Delete Session and Scan Again', 'categories', 'botname'];
    _0x1466 = function () {
        return _0xc15d17;
    };
    return _0x1466();
}